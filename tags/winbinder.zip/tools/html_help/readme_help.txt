------------------------------------------------------------------------------

README file for HTML Help

------------------------------------------------------------------------------

Displaying help for WinBinder keywords
--------------------------------------

You may configure your favorite source code editor display help for WinBinder keywords. To do so, follow the steps below:

1) Create a tool that points to winbinder.chm. In my case it is at C:\@desenv\WinBinder\wimbinder_manual.chm.
2) Assign a keyboard shortcut to the newly created tool. Now you can highlight and display help for WinBinder keywords simply by moving the text cursor to the desired word and pressing one key.

If you use TextPad, see also tools\textpad\readme_textpad.txt for more configuration tips.

------------------------------------------------------------------------------

I'd very much appreciate if you sent me corrections or updated information about this document, or a procedure for a different tool. Please contact me at:

Rubem Pechansky
http://www.hypervisual.com/winbinder/contact.php
