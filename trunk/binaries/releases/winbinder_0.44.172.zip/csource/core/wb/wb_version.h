
// Current WinBinder version
// This file is generated automatically by WinBinder Release Maker.

#define WINBINDER_VERSION		"0.44.172"
