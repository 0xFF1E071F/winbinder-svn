I've added this folder to place the release files on it. I don't know if this is the standard behavior, so please tell me if there is a better and/or usual way.


Thanks, Rubem